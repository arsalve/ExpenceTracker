/*
 * Financial Insights - single, consistent frontend implementation.
 *
 * Expected API:
 *   POST /api/statistics
 *   body: { user, year }
 *
 * Expected response:
 *   {
 *     success: true,
 *     stats: {
 *       total_income: number,
 *       total_expense: number,
 *       total_savings: number,
 *       net_balance: number,
 *       monthly_breakdown: {
 *         "01": { income, expense, savings },
 *         ...
 *       }
 *     }
 *   }
 */

(() => {
    'use strict';

    const API_BASE = '/api';

    const TYPE_ALIASES = {
        income: 'income',
        credit: 'income',
        expense: 'expense',
        debit: 'expense',
        savings: 'savings',
        saving: 'savings',
        Savings: 'savings'
    };

    class InsightsManager {
        constructor() {
            this.currentUser = this.getUser();
            this.initialize();
        }

        getUser() {
            const stored = localStorage.getItem('currentUser');
            if (stored && stored.trim()) return stored.trim();

            const hashUser = decodeURIComponent(
                window.location.hash.replace(/^#/, '').trim()
            );

            if (hashUser) {
                localStorage.setItem('currentUser', hashUser);
                return hashUser;
            }

            return '';
        }

        initialize() {
            this.setupThemeToggle();
            this.setupUserControls();
            this.setupButtons();

            const yearInput = document.getElementById('analysisYear');
            if (yearInput) {
                yearInput.value = new Date().getFullYear();
            }

            this.loadAnalytics();
        }

        setupThemeToggle() {
            const toggle = document.getElementById('themeToggle');
            if (!toggle) return;

            toggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const isDark = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', isDark ? '1' : '0');
                this.redrawCharts();
            });

            if (localStorage.getItem('darkMode') === '1') {
                document.body.classList.add('dark');
            }
        }

        setupUserControls() {
            const userInput = document.getElementById('currentUserInput');
            const userForm = document.getElementById('userForm');

            if (userInput) {
                userInput.value = this.currentUser;
            }

            if (userForm) {
                userForm.addEventListener('submit', event => {
                    event.preventDefault();

                    const value = userInput?.value?.trim() || '';

                    if (!value) {
                        this.showError('कृपया वापरकर्त्याचे नाव लिहा.');
                        return;
                    }

                    this.currentUser = value;
                    localStorage.setItem('currentUser', value);
                    this.loadAnalytics();
                });
            }
        }

        setupButtons() {
            const loadButton = document.getElementById('loadAnalysisBtn');
            const exportButton = document.getElementById('exportDataBtn');

            if (loadButton) {
                loadButton.addEventListener('click', () => this.loadAnalytics());
            }

            if (exportButton) {
                exportButton.addEventListener('click', () => this.exportData());
            }
        }

        async loadAnalytics() {
            const yearElement = document.getElementById('analysisYear');
            const year = Number(yearElement?.value) || new Date().getFullYear();

            if (!this.currentUser) {
                this.showError('कृपया आधी वापरकर्ता नाव सेट करा.');
                return;
            }

            this.setLoading(true);
            this.hideError();

            try {
                const response = await fetch(`${API_BASE}/statistics`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        user: this.currentUser,
                        year
                    })
                });

                const payload = await this.readJson(response);

                if (!response.ok) {
                    throw new Error(payload?.message || `Server error ${response.status}`);
                }

                const stats = payload?.stats || payload?.data || payload;

                if (!stats || typeof stats !== 'object') {
                    throw new Error('Statistics response is empty or invalid.');
                }

                this.displayStatistics(this.normalizeStats(stats));
            } catch (error) {
                console.error('Analytics error:', error);
                this.showError(
                    `विश्लेषण लोड करता आले नाही. ${error.message || 'कृपया पुन्हा प्रयत्न करा.'}`
                );
                this.displayStatistics(this.emptyStats());
            } finally {
                this.setLoading(false);
            }
        }

        async readJson(response) {
            const text = await response.text();

            if (!text) return {};

            try {
                return JSON.parse(text);
            } catch {
                throw new Error('Server ने वैध JSON response दिला नाही.');
            }
        }

        emptyStats() {
            const monthly_breakdown = {};

            for (let month = 1; month <= 12; month++) {
                monthly_breakdown[String(month).padStart(2, '0')] = {
                    income: 0,
                    expense: 0,
                    savings: 0
                };
            }

            return {
                total_income: 0,
                total_expense: 0,
                total_savings: 0,
                net_balance: 0,
                monthly_breakdown
            };
        }

        normalizeNumber(value) {
            const number = Number(value);
            return Number.isFinite(number) ? number : 0;
        }

        normalizeStats(stats) {
            const empty = this.emptyStats();

            const monthly = stats.monthly_breakdown ||
                stats.monthlyBreakdown ||
                {};

            const normalizedMonthly = {};

            for (let month = 1; month <= 12; month++) {
                const key = String(month).padStart(2, '0');

                const source =
                    monthly[key] ||
                    monthly[String(month)] ||
                    monthly[month] ||
                    {};

                normalizedMonthly[key] = {
                    income: this.normalizeNumber(
                        source.income ?? source.total_income
                    ),
                    expense: this.normalizeNumber(
                        source.expense ??
                        source.expenses ??
                        source.total_expense
                    ),
                    savings: this.normalizeNumber(
                        source.savings ??
                        source.total_savings
                    )
                };
            }

            let totalIncome = this.normalizeNumber(
                stats.total_income ?? stats.totalIncome
            );

            let totalExpense = this.normalizeNumber(
                stats.total_expense ??
                stats.totalExpense ??
                stats.total_expenses
            );

            let totalSavings = this.normalizeNumber(
                stats.total_savings ??
                stats.totalSavings
            );

            /*
             * If the backend did not send totals, calculate them
             * from monthly data.
             */
            if (
                totalIncome === 0 &&
                totalExpense === 0 &&
                totalSavings === 0
            ) {
                for (const month of Object.values(normalizedMonthly)) {
                    totalIncome += month.income;
                    totalExpense += month.expense;
                    totalSavings += month.savings;
                }
            }

            const suppliedBalance = stats.net_balance ?? stats.netBalance;

            const netBalance =
                suppliedBalance !== undefined
                    ? this.normalizeNumber(suppliedBalance)
                    : totalIncome - totalExpense - totalSavings;

            return {
                total_income: totalIncome,
                total_expense: totalExpense,
                total_savings: totalSavings,
                net_balance: netBalance,
                monthly_breakdown: normalizedMonthly
            };
        }

        displayStatistics(stats) {
            this.setText('totalIncome', this.money(stats.total_income));
            this.setText('totalExpense', this.money(stats.total_expense));
            this.setText('totalSavings', this.money(stats.total_savings));
            this.setText('netBalance', this.money(stats.net_balance));

            const income = stats.total_income;
            const expense = stats.total_expense;
            const savings = stats.total_savings;

            const expensePercent = income > 0 ? (expense / income) * 100 : 0;
            const savingsPercent = income > 0 ? (savings / income) * 100 : 0;
            const balancePercent =
                income > 0 ? (stats.net_balance / income) * 100 : 0;

            this.setText(
                'expensePercentage',
                `खर्च: ${expensePercent.toFixed(1)}%`
            );

            this.setText(
                'savingsPercentage',
                `बचत: ${savingsPercent.toFixed(1)}%`
            );

            this.setText(
                'balancePercentage',
                `शिल्लक: ${balancePercent.toFixed(1)}%`
            );

            this.stats = stats;

            this.drawMonthlyTrendChart(stats.monthly_breakdown);
            this.drawExpenseDistributionChart(stats.monthly_breakdown);
            this.generateRecommendations(stats);
        }

        setText(id, value) {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        }

        money(value) {
            return new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                maximumFractionDigits: 2
            }).format(this.normalizeNumber(value));
        }

        getMonthData(monthlyData) {
            const months = [];

            for (let i = 1; i <= 12; i++) {
                const key = String(i).padStart(2, '0');

                months.push({
                    key,
                    label: new Date(2000, i - 1, 1).toLocaleString(
                        'en-IN',
                        { month: 'short' }
                    ),
                    ...(monthlyData[key] || {
                        income: 0,
                        expense: 0,
                        savings: 0
                    })
                });
            }

            return months;
        }

        getChartTheme() {
            const dark = document.body.classList.contains('dark');

            return {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: {
                    color: dark ? '#f9fafb' : '#111827'
                },
                xaxis: {
                    gridcolor: dark ? '#374151' : '#e5e7eb'
                },
                yaxis: {
                    gridcolor: dark ? '#374151' : '#e5e7eb'
                }
            };
        }

        drawMonthlyTrendChart(monthlyData) {
            const element = document.getElementById('monthlyTrendChart');

            if (!element || typeof Plotly === 'undefined') return;

            const months = this.getMonthData(monthlyData);

            const incomeTrace = {
                x: months.map(m => m.label),
                y: months.map(m => m.income),
                name: 'उत्पन्न',
                type: 'scatter',
                mode: 'lines+markers'
            };

            const expenseTrace = {
                x: months.map(m => m.label),
                y: months.map(m => m.expense),
                name: 'खर्च',
                type: 'scatter',
                mode: 'lines+markers'
            };

            Plotly.react(
                element,
                [incomeTrace, expenseTrace],
                {
                    ...this.getChartTheme(),
                    title: 'मासिक उत्पन्न व खर्च',
                    margin: { t: 50, r: 20, b: 50, l: 60 },
                    legend: { orientation: 'h' }
                },
                { responsive: true, displaylogo: false }
            );
        }

        drawExpenseDistributionChart(monthlyData) {
            const element = document.getElementById('expenseDistributionChart');

            if (!element || typeof Plotly === 'undefined') return;

            const months = this.getMonthData(monthlyData);

            Plotly.react(
                element,
                [{
                    x: months.map(m => m.label),
                    y: months.map(m => m.expense),
                    type: 'bar',
                    name: 'खर्च'
                }],
                {
                    ...this.getChartTheme(),
                    title: 'मासिक खर्च',
                    margin: { t: 50, r: 20, b: 50, l: 60 },
                    yaxis: { ...this.getChartTheme().yaxis, title: 'रक्कम (₹)' }
                },
                { responsive: true, displaylogo: false }
            );
        }

        redrawCharts() {
            if (!this.stats) return;

            this.drawMonthlyTrendChart(this.stats.monthly_breakdown);
            this.drawExpenseDistributionChart(this.stats.monthly_breakdown);
        }

        generateRecommendations(stats) {
            const list = document.getElementById('recommendationsList');

            if (!list) return;

            const income = stats.total_income;
            const expense = stats.total_expense;
            const savings = stats.total_savings;
            const balance = stats.net_balance;

            const recommendations = [];

            if (income <= 0) {
                recommendations.push(
                    'या कालावधीत उत्पन्नाची नोंद आढळली नाही. प्रथम उत्पन्नाच्या नोंदी तपासा.'
                );
            } else {
                const expenseRatio = expense / income;
                const savingsRatio = savings / income;

                if (expenseRatio > 0.50) {
                    recommendations.push(
                        `आपला खर्च उत्पन्नाच्या ${(
                            expenseRatio * 100
                        ).toFixed(1)}% आहे. अनावश्यक खर्च कमी करण्याचा प्रयत्न करा.`
                    );
                }

                if (savingsRatio < 0.20) {
                    recommendations.push(
                        `आपली बचत उत्पन्नाच्या ${(
                            savingsRatio * 100
                        ).toFixed(1)}% आहे. शक्य असल्यास किमान 20% बचतीचे लक्ष्य ठेवा.`
                    );
                }

                if (savingsRatio >= 0.20) {
                    recommendations.push(
                        'छान! आपण उत्पन्नाच्या किमान 20% बचत करत आहात.'
                    );
                }

                if (expenseRatio < 0.30) {
                    recommendations.push(
                        'आपला खर्च तुलनेने कमी आहे. उरलेल्या रकमेचा काही भाग आपत्कालीन निधी किंवा दीर्घकालीन उद्दिष्टांसाठी वापरू शकता.'
                    );
                }
            }

            if (balance < 0) {
                recommendations.push(
                    'आपली शिल्लक नकारात्मक आहे. खर्च आणि बचतीचे नियोजन पुन्हा तपासा.'
                );
            } else if (balance > 0) {
                recommendations.push(
                    'आपल्याकडे सकारात्मक शिल्लक आहे. ती रक्कम आपल्या आर्थिक उद्दिष्टांकडे वळवण्याचा विचार करा.'
                );
            }

            if (!recommendations.length) {
                recommendations.push(
                    'पुरेसा डेटा मिळाल्यावर अधिक वैयक्तिक आर्थिक सूचना येथे दिसतील.'
                );
            }

            list.innerHTML = recommendations
                .map(item => `<li>${this.escapeHtml(item)}</li>`)
                .join('');
        }

        escapeHtml(value) {
            return String(value)
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;')
                .replaceAll('>', '&gt;')
                .replaceAll('"', '&quot;')
                .replaceAll("'", '&#039;');
        }

        setLoading(isLoading) {
            const button = document.getElementById('loadAnalysisBtn');
            const status = document.getElementById('loadingStatus');

            if (button) {
                button.disabled = isLoading;
                button.textContent = isLoading
                    ? 'लोड होत आहे...'
                    : 'विश्लेषण लोड करा';
            }

            if (status) {
                status.hidden = !isLoading;
            }
        }

        showError(message) {
            const element = document.getElementById('errorMessage');

            if (element) {
                element.textContent = message;
                element.hidden = false;
            }
        }

        hideError() {
            const element = document.getElementById('errorMessage');

            if (element) {
                element.hidden = true;
                element.textContent = '';
            }
        }

        async exportData() {
            if (!this.currentUser) {
                this.showError('कृपया आधी वापरकर्ता नाव सेट करा.');
                return;
            }

            try {
                const response = await fetch(`${API_BASE}/export/json`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        user: this.currentUser
                    })
                });

                const payload = await this.readJson(response);

                if (!response.ok) {
                    throw new Error(
                        payload?.message || `Export failed (${response.status})`
                    );
                }

                const blob = new Blob(
                    [JSON.stringify(payload, null, 2)],
                    { type: 'application/json;charset=utf-8' }
                );

                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');

                link.href = url;
                link.download =
                    `financial-data-${this.currentUser}-${Date.now()}.json`;

                document.body.appendChild(link);
                link.click();
                link.remove();

                URL.revokeObjectURL(url);
            } catch (error) {
                console.error('Export error:', error);
                this.showError(
                    `डेटा export करता आला नाही. ${error.message || ''}`
                );
            }
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        window.insightsManager = new InsightsManager();
    });
})();
